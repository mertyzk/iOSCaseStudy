//
//  AlertConstant.swift
//  E-Market
//
//  Created by Macbook Air on 28.12.2024.
//

import Foundation

enum AlertConstants {
    static let errorTitle = "Something went wrong!"
}
