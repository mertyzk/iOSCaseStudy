//
//  FavoriteDB.swift
//  E-Market
//
//  Created by Macbook Air on 29.12.2024.
//

import Foundation

typealias FavoriteHandler = BaseDB

