//
//  FavoritesVM.swift
//  E-Market
//
//  Created by Macbook Air on 27.12.2024.
//

import Foundation

final class FavoritesVM {
    var favoriteHandler: FavoriteHandler
    
    init(favoriteHandler: FavoriteHandler) {
        self.favoriteHandler = favoriteHandler
    }
    
    func addFavorite(product: Product) async throws {
        
    }
}
